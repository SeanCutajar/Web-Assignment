<?php

ini_set("default-charset", "UTF-8");


// Database settings
define('dbhost', 'localhost');
define('dbuser', 'root');
define('dbpass', '');
define('dbname', 'therestaurant');



date_default_timezone_set("America/Toronto");




function validate($field, $l_limit, $u_limit, $value, $extra = ''){
	
	if(strlen($value) < $l_limit){
		$GLOBALS['global_report'] .=  'Too few characters for '.$field.' minimum: '.$l_limit.'<br>';
		return;
	}
	if(strlen($value) > $u_limit){
		$GLOBALS['global_report'] .=  'Too long characters for '.$field.' maximum: '.$u_limit.'<br>';
		return;
	}
    
	return htmlspecialchars($value,  ENT_COMPAT);
}

function format_currency($str){
	
	return '$'.number_format($str, '2', '.', ',');	
}


function check_admin_login($ch){
	
	if(isset($_SESSION['admin'])){
		$pass_sssss = true; //do nothing
	}
	else{
		if($ch == 0)
			header('Location: ./login.php');
		else
			die('Please login');
		
	}
	
	
}



class mypdo{
	 public $pdc = null;
	 public function __construct(){
		 $host = dbhost;
		 $db   =  dbname;
		 $user  =  dbuser;
		 $pass  =   dbpass;
		 $charset = 'utf8mb4';
		 $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
		 $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false,];
		 $this->pdc = new PDO($dsn, $user, $pass, $opt);
		 }
	 
	 
	
	/* This method help to query the database  with one argument */	  
    public function gen_qry_one($qry, $id){
		 
		 $stmt = $this->pdc->prepare($qry);
	     $stmt->bindParam(1, $id, PDO::PARAM_INT);
         $stmt->execute();		
	}
	
	
	public function add_contact_us($fname, $email, $subject, $message, $review, $date_time){
		
		$qry = "INSERT INTO contacts(fname, email, subject, message, review, date_time)VALUES(?, ?, ?, ?, ?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $fname, PDO::PARAM_STR);
		$stmt->bindParam(2, $email, PDO::PARAM_STR);
		$stmt->bindParam(3, $subject, PDO::PARAM_STR);
		$stmt->bindParam(4, $message, PDO::PARAM_STR);
		$stmt->bindParam(5, $review, PDO::PARAM_STR);
		$stmt->bindParam(6, $date_time, PDO::PARAM_STR);
		$stmt->execute();
		return "success";
	}
	
	
	public function new_reservation($fname, $email, $phone, $class, $quantity, $date_time){
		
		$qry = "INSERT INTO reservation(fname, email, phone, class, quantity, date_time)VALUES(?, ?, ?, ?, ?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $fname, PDO::PARAM_STR);
		$stmt->bindParam(2, $email, PDO::PARAM_STR);
		$stmt->bindParam(3, $phone, PDO::PARAM_STR);
		$stmt->bindParam(4, $class, PDO::PARAM_STR);
		$stmt->bindParam(5, $quantity, PDO::PARAM_STR);
		$stmt->bindParam(6, $date_time, PDO::PARAM_STR);
		$stmt->execute();
		return "success";
	}
	
	public function add_category($cat_name){
		
		$qry = "INSERT INTO categories(name)VALUES(?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $cat_name, PDO::PARAM_STR);
		$stmt->execute();
		return "success".$this->pdc->lastInsertId();
	}
	
	
	public function get_categories(){
		$qry = "SELECT id, name FROM categories ORDER BY name";
		$stmt = $this->pdc->prepare($qry);
		$stmt->execute();
		return $stmt->fetchAll();
		
	}
	
	
	public function get_menus(){
		$qry = "SELECT a.*, b.name as cat_name, b.id as cat_id  FROM menu a LEFT JOIN categories b ON a.category = b.id ORDER BY a.name";
		$stmt = $this->pdc->prepare($qry);
		$stmt->execute();
		return $stmt->fetchAll();
		
	}
	
	public function get_single_menu($mid){
		$qry = "SELECT a.*, b.name as cat_name, b.id as cat_id  FROM menu a LEFT JOIN categories b ON a.category = b.id  WHERE a.id = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $mid, PDO::PARAM_INT);
		$stmt->execute();
		return $stmt->fetch();
		
	}
	
	
	public function add_menu($category, $name, $desc_n, $price){
		
		$qry = "INSERT INTO menu(category, name, desc_n, price)VALUES(?, ?, ?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1,$category, PDO::PARAM_INT);
		$stmt->bindParam(2, $name, PDO::PARAM_STR);
		$stmt->bindParam(3, $desc_n, PDO::PARAM_STR);
		$stmt->bindParam(4, $price, PDO::PARAM_STR);
		$stmt->execute();
		return "success".$this->pdc->lastInsertId();
	}
	
	public function update_menu($category, $dstatus, $desc_n, $price, $mid){
		
		$qry = "UPDATE menu SET category = ?, name = ?, desc_n = ?, price = ? WHERE id = ?";
			
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1,$category, PDO::PARAM_INT);
		$stmt->bindParam(2, $dstatus, PDO::PARAM_STR);
		$stmt->bindParam(3, $desc_n, PDO::PARAM_STR);
		$stmt->bindParam(4, $price, PDO::PARAM_STR);
	   $stmt->bindParam(5, $mid, PDO::PARAM_INT);
		$stmt->execute();
		return "success";
	}
	
	public function delete_menu($mid){
		
		$qry = "DELETE FROM menu  WHERE id = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $mid, PDO::PARAM_INT);
		$stmt->execute();
		return "success";
	}
	
	public function get_reservations(){
		
		$qry = "SELECT * FROM reservation ORDER BY id DESC";
		$stmt = $this->pdc->prepare($qry);
		$stmt->execute();
		return $stmt->fetchAll();
	}
	
	public function get_contacts(){
		
		$qry = "SELECT * FROM contacts ORDER BY id DESC";
		$stmt = $this->pdc->prepare($qry);
		$stmt->execute();
		return $stmt->fetchAll();
	}
	
	
	public function get_favourite($favourite){
		
		$qry = "SELECT a.*, b.name as cat_name, b.id as cat_id  FROM menu a LEFT JOIN categories b ON a.category = b.id WHERE a.id IN ($favourite) ORDER BY name";
		$stmt = $this->pdc->prepare($qry);
		$stmt->execute();
		return $stmt->fetchAll();
	}
	
	
	
	
	

}




function get_login_html(){
  
  if(!isset($_SESSION['admin'])){
	  
	return '<span><a href="favourite.php" id="favourite_count">fav </a></span>';  
  }
  else{
	  
	 return  '<span><div class="dropdown">
				  <button onClick="toggle_dropdow()" class="dropbtn">'.$_SESSION['user'].' <b> &#94;</b></button>
				  <ul class="dropdown-content">'.
				     '<li><a href="admin">Admin Area</a></li>'
					.'<li><a href="admin/logout.php">Logout</a></li>
				  </ul>
				</div>
			  </span><span><a href="favourite.php" id="favourite_count"></a></span>';
	}	
	
	
}

function get_login_admin_html(){
  
	  
	 return  '<span><div class="dropdown">
				  <button onClick="toggle_dropdow()" class="dropbtn">'.$_SESSION['user'].' <b> &#94;</b></button>
				  <ul class="dropdown-content">
				   <li><a href="./logout.php">Logout</a></li>
				  </ul>
				</div>
			  </span><span><a href="../favourite.php" id="favourite_count"></a></span>';
		
}


