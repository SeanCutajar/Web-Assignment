<?php
session_start();

require 'config/config.php';

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/main.css">
    <title>The Taste Experience</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="#" class="active">Home</a>
        <a href="#about_us">About US</a>
        <a href="menu.php">Menu</a>
        <a href="contact-us.php">Contact Us</a>
        <a href="reservation.php">Reservation</a>
        <?php echo get_login_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="images/menu_bar.png">
        </a>
    </nav>

    <header class="home_header">
        <div class="container">
            <h2 class="home-title"> <span>The </span>Taste <span> Experience </span></h2>
            <div class="home-slag-1">We are your favourite meal outlet. Your taste is of paramount importance to us.
            </div>

        </div>

        <a class="home-btn" href="menu.php">Our Menu</a>
    </header>


    <section class="about_section">
        <div class="container" id="about_us">

            <div class="sub_header">
                <h2>The Taste Experience</h2>
            </div>

            <p> Since 1970, The Taste Experience has been the go-to restaurant for the residents of Pembroke and all
                neighboring localities. </p>
            <p>
                This restaurant is a family-run business that has been passed down through generations. Our restaurant
                serves breakfast all day in addition to wholesome and flavorful dining options for lunch and dinner.
            </p>
            <p>
                From pizzas to salads, seafood to burgers, you will find all kinds of delicious meals prepared fresh at
                The Taste Experience. Additionally, we serve delicious baked goods and other treats, including our
                popular cherry pie, based on the original recipe of our great-grandmother. </p>

            <p>From the moment you step into The Taste Experience, it is immediately noticed where it gets its long-held
                reputation for excellence. It starts with a subtle sense of elegance.
            </p>
            <p>
                The tasteful decor enhances the beautiful architecture of the townhouse, with its perfectly preserved
                wooden windows, beams and trademark yellow masonry.</p>

        </div>
    </section>

    <section class="booking_section">
        <div class="container">
            <p>Save time finding the perfect table for you and your friends or family when coming to our restaurant</p>
            <a href="reservation.php">Reserve a Table</a>
        </div>
    </section>


    <section class="openning_section">
        <div class="container">

            <div class="sub_header">
                <h2>Opening Hours</h2>
            </div>
            <p>The Opening Hours of The Taste Experience are as follows</p>
            <table>
                <tr>
                    <td>Monday:</td>
                    <td style="color:red">Closed</td>
                </tr>
                <tr>
                    <td>Tuesday:</td>
                    <td style="color:red">Closed</td>
                </tr>
                <tr>
                    <td>Wednesday:</td>
                    <td>9am - 5pm</td>
                </tr>
                <tr>
                    <td>Thursday:</td>
                    <td>9am - 5pm</td>
                </tr>
                <tr>
                    <td>Friday:</td>
                    <td>9am - 11pm</td>
                </tr>
                <tr>
                    <td>Saturday:</td>
                    <td>9am - 11pm</td>
                </tr>
                <tr>
                    <td>Sunday:</td>
                    <td>9am - 11pm</td>
                </tr>
            </table>

        </div>
    </section>


    <section class="contact_section">
        <div class="container">

            <div style="text-align:center" class="sub_header">
                <h2>Our Location</h2>
            </div>

            <p>245, West Lane; </p>

            <a>Contact Us</a>

        </div>
    </section>


    <div>







    </div>





    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>

</body>

</html>