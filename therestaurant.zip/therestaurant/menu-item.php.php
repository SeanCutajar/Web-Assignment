<?php
session_start();

require 'config/config.php';

if(!isset($_REQUEST['m_id']))
	header('Location: menu.php');

$pdo = new mypdo();
$mid = $_REQUEST['m_id'];
$menu = $pdo->get_single_menu($mid);

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/main.css">
    <title><?php echo $menu['name']; ?></title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="./">Home</a>
        <a href="./#about_us">About US</a>
        <a class="active" href="menu.php">Menu</a>
        <a href="contact-us.php">Contact Us</a>
        <a href="reservation.php">Reservation</a>
        <?php echo get_login_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <h2 class="home-title"><?php echo $menu['name']; ?></h2>
        </div>
    </header>
    <section class="news_section">
        <div class="container">

            <div class="favourite" id="favourite" data-id="<?php echo $menu['id']; ?>"><button style="display:none"
                    onClick="add_item_to_favourite(<?php echo $menu['id']; ?>)">&plus; Add to Favourite</button></div>

            <div class="menu-item">
                <div class="dstatus"><?php echo $menu['name']; ?> </div>
                <div class="price" style="font-size:25px; margin-top:10px;">
                    <?php echo format_currency($menu['price']); ?></div>

                <div class="cat_level"><span>Category:</span> <?php echo $menu['cat_name']; ?> </div>

            </div>

            <div style="padding:20px">
                <h3 style="text-decoration:underline">Description</h3>
                <p style="margin-top:30px; line-height:30px; white-space:pre-wrap"><?php echo $menu['desc_n']; ?></p>


            </div>


        </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>

</body>

</html>