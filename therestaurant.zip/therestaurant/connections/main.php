<?php 
require "../config/config.php";

/** This is a global variable used to store errors globally  */
$GLOBALS['global_report'] = '';



/** This code block add Contact/review message to the contact table.
	The validate function is the the config.php file 
	The $pdo class is in the config.php file  which is imported
	
**/
if(isset($_POST['ch']) && $_POST['ch'] == 'contact_us'){
	
	$fname = validate('fname', 4, 50, $_POST['fname']);
	$email = validate('email', 6, 50, $_POST['email']);
	$subject = validate('subject', 2, 50, $_POST['subject']);
	$message = validate('message', 5, 1000, $_POST['message']);
	$review = validate('review', 0, 50, $_POST['review']);
	
	$date_time = date('Y-m-d H:i:s');
	
	
	if($GLOBALS['global_report'] !== '') //validation failed
		die($GLOBALS['global_report']);
	$pdo = new mypdo();
	
	$response = $pdo->add_contact_us($fname, $email, $subject, $message, $review, $date_time);
	
	die($response);

}



/** This code block add table reservation to the Reservation table.
	The validate function is the the config.php file 
	The $pdo class is in the config.php file  which is imported
	
**/
if(isset($_POST['ch']) && $_POST['ch'] == 'reservation'){
	
	$fname = validate('fname', 4, 50, $_POST['fname']);
	$email = validate('email', 6, 50, $_POST['email']);
	$phone = validate('subject', 2, 50, $_POST['phone']);
	
	$reservation = json_decode($_POST['reservation'], true);
	
	$pdo = new mypdo();
	// We will iterate over the array and insert all row to the table
	foreach($reservation as $reserv){
		//name, date, time, amount
		
		$class =  $reserv[0];
		$date =  date('Y-m-d H:i', strtotime($reserv[1] . ' ' . $reserv[2])); // add both the date and time component
		$amount =  $reserv[3];
		
		$pdo->new_reservation($fname, $email, $phone, $class, $amount, $date);
		
	}
	
	die('success');

}


/** This code block add table reservation to the Reservation table.
	The validate function is the the config.php file 
	The $pdo class is in the config.php file  which is imported
	
**/

if(isset($_POST['ch']) && $_POST['ch'] == 'get_favourite'){
	
	$favourite = json_decode($_POST['favourite_str'], true);
	
	$clean_favourite = array('0');
	foreach($favourite as $fav){
		$clean_favourite[] = (int)$fav;  // Ensure we have only integer
	}
	
	$favourite_str = implode(', ', $clean_favourite);
	
	$pdo = new mypdo();
	$menus = $pdo->get_favourite($favourite_str);
	
	die(json_encode($menus));

}






