/**
	Function to toggle menu 
	
*/

function myFunction() {
	var x = document.getElementById("myTopnav");
	if (x.className === "topnav") {
		x.className += " responsive";
	} else {
		x.className = "topnav";
	}
}


/* Control function to view menus for different subcategories  */

function view_menu(cat_n) {

	var menu_items = document.querySelectorAll('.menu-item-p');

	var menu_tabs = document.querySelectorAll('.home-slag-3 a');
	for (var i = 0; i < menu_tabs.length; i++)
		menu_tabs[i].classList.remove('active');

	document.getElementById('tab_' + cat_n).classList.add('active');


	if (cat_n == 'all') {
		for (var i = 0; i < menu_items.length; i++)
			menu_items[i].style.display = 'inline-block';
		return;

	}

	for (var i = 0; i < menu_items.length; i++)
		menu_items[i].style.display = 'none';


	var menu_items = document.querySelectorAll('.cat_' + cat_n);
	for (var i = 0; i < menu_items.length; i++)
		menu_items[i].style.display = 'inline-block';

}



/*
	this is the function use to toggle the menu while in mobile view
	
*/
function toggle_dropdow() {

	var dropdown_content = document.querySelector('.dropdown-content');
	var caret_ind = document.querySelector('.dropbtn b');

	if (dropdown_content.style.display == 'none' || dropdown_content.style.display == '') {
		dropdown_content.style.display = 'block';
		caret_ind.style.transform = 'rotate(0deg)';
	}
	else {
		dropdown_content.style.display = 'none';
		caret_ind.style.transform = 'rotate(180deg)';
	}

}



/*
	Cantact form submission. It uses AJAX POST to submit form to the backend main,php script
	
*/

function contact_us(event) {
	event.preventDefault(); // prevent natural form submission

	var fname = document.getElementById("fname").value;
	var email = document.getElementById("email").value;
	var subject = document.getElementById("subject").value;
	var message = document.getElementById("message").value;
	if (document.querySelector('input[name="review"]:checked'))
		var review = document.querySelector('input[name="review"]:checked').value;
	else
		var review = '';

	var formData = new FormData();
	formData.append('fname', fname);
	formData.append('email', email);
	formData.append('subject', subject);
	formData.append('message', message);
	formData.append('review', review);
	formData.append('ch', 'contact_us');

	document.getElementById("report").innerHTML = '';
	var bfr_cont = document.getElementById("process_div").innerHTML;
	document.getElementById("process_div").innerHTML = '<img src="./images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			document.getElementById("process_div").innerHTML = bfr_cont;
			if (xmlHttp.responseText == 'success') {
				document.getElementById('contact_form').reset();
				document.getElementById("process_div").innerHTML = '<div style="padding:10px; text-align:center; background-color:#E6F5E0; font-size:24px;"> Thanks for contacting us. We will get back to you as soon as posible.</div>';
			}
			else {

				document.getElementById("report").innerHTML = xmlHttp.responseText;

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}





/*
	Reservation form submission. It uses AJAX POST to submit form to the backend main,php script
	
*/

function book_reservation(event) {
	event.preventDefault(); // prevent natural form submission

	var reservation = [];

	for (var i = 0; i < 3; i++) {

		var table_row = "#row_" + i;

		var date = document.querySelector(table_row + ' .date').value;
		var time = document.querySelector(table_row + ' .time').value;
		var amount = document.querySelector(table_row + ' .amount').value;
		var name = document.querySelector(table_row + ' .name').innerHTML;

		// We only care if the user select all field for this row
		if (!(date == '' || time == '' || amount == '')) {
			reservation.push([name, date, time, amount]);
		}
	}
	if (reservation.length == 0) {
		alert('You have to select at least one row.');
		return;

	}
	var reservation_json = JSON.stringify(reservation);


	var fname = document.getElementById("fname").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;


	var formData = new FormData();
	formData.append('fname', fname);
	formData.append('email', email);
	formData.append('phone', phone);
	formData.append('reservation', reservation_json);
	formData.append('ch', 'reservation');


	document.getElementById("report").innerHTML = '';
	var bfr_cont = document.getElementById("process_div").innerHTML;
	document.getElementById("process_div").innerHTML = '<img src="./images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			document.getElementById("process_div").innerHTML = bfr_cont;
			if (xmlHttp.responseText == 'success') {
				document.getElementById('contact_form').reset();
				document.getElementById("process_div").innerHTML = '<div style="padding:40px; text-align:center; background-color:#E6F5E0; font-size:24px;"> Thanks for booking a table. We will call you to confirm your reservation.</div>';
			}
			else {

				document.getElementById("report").innerHTML = xmlHttp.responseText;

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}



/* function to add item to favourite */;
function add_item_to_favourite(mid) {

	/**
		We will use the browser local storage .
		We don't need to send data to the serve, so cookies is not necessary 
	*/

	if (mid == null) return;
	var favourite_str = localStorage.getItem('favourite');
	if (favourite_str == '' || favourite_str == null)
		var favourite = [];
	else
		var favourite = JSON.parse(favourite_str); // covert to array

	favourite.push(mid);

	var favourite_count = favourite.length;

	var favourite_str = JSON.stringify(favourite);  // Convert back to string

	localStorage.setItem('favourite', favourite_str);

	document.getElementById('favourite').innerHTML = '<p>Item added to <span style="font-size:25px; color:#F90">&hearts;</span> Favourite</p>';

	document.getElementById("favourite_count").innerHTML = '<i>&hearts;</i>favourite(' + favourite_count + ')';


}



/* function to remove item to favourite */;
function delete_favourite(mid) {

	var favourite_str = localStorage.getItem('favourite');
	if (favourite_str == '' || favourite_str == null)
		var favourite = [];
	else
		var favourite = JSON.parse(favourite_str); // covert to array

	var new_favourite = [];
	favourite.forEach(function (fav) {
		if (!(fav == mid || fav == null || fav == ''))
			new_favourite.push(fav);

	});

	var favourite_count = new_favourite.length;

	var favourite_str = JSON.stringify(new_favourite);  // Convert back to string

	localStorage.setItem('favourite', favourite_str);

	document.getElementById("favourite_count").innerHTML = '<i>&hearts;</i>favourite(' + favourite_count + ')';

	document.getElementById('row_' + mid).remove();

}


function fetch_favourite(favourite_str) {


	var formData = new FormData();
	formData.append('favourite_str', favourite_str);
	formData.append('ch', 'get_favourite');

	var bfr_cont = document.getElementById("favourite_table").innerHTML;
	document.getElementById("favourite_table").innerHTML = '<img src="./images/spinner.gif" style="width:3.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			document.getElementById("favourite_table").innerHTML = bfr_cont;

			try {
				var menus = JSON.parse(xmlHttp.responseText);
				var sn = 1;
				menus.forEach(function (menu) {

					var row = document.createElement('tr');
					row.id = 'row_' + menu['id'];
					row.innerHTML = '<tr><td>' + sn + '</td><td>' + menu['name'] + '</td><td>' + menu['cat_name'] + '</td><td>$' + menu['price'] + '</td><td class="edit_area" onclick="delete_favourite(' + menu['id'] + ')"><button> &times; </button></td></tr>';
					document.getElementById('favourite_menus').append(row);

					sn++;

				});

			} catch (exception) {

				alert(xmlHttp.responseText);
			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}


(function () {

	// This block update the favourite count in the nav tab whenever the page load completely

	var favourite_str = localStorage.getItem('favourite');
	if (favourite_str == '' || favourite_str == null)
		var favourite = [];
	else
		var favourite = JSON.parse(favourite_str); // covert to array


	var favourite_count = favourite.length;
	document.getElementById("favourite_count").innerHTML = '<i>&hearts;</i>favourite(' + favourite_count + ')';

	// While in the menu-item page, check if this item is already in favourite
	var fav_elm = document.getElementById('favourite');
	if (fav_elm != null) {
		var mid = parseInt(fav_elm.getAttribute('data-id'));
		if (favourite.includes(mid)) {
			fav_elm.innerHTML = '<p>Item added to <span style="font-size:25px; color:#F90">&hearts;</span> Favourite</p>';
		}
		else {
			document.querySelector("#favourite button").style.display = 'inline-block';
		}

	}


	// While in the favourite page, fetch favourite menus
	var fav_elm = document.getElementById('favourite_menus');
	if (fav_elm != null) {

		if (favourite_str == '' || favourite_str == null || favourite.length == 0) {

			document.getElementById('favourite_nop').style.display = 'block';

		}
		else {
			document.getElementById('favourite_table').style.display = 'block';
			// Fetch the favourite menus
			fetch_favourite(favourite_str);

		}

	}



})();