
function add_category(event) {
	event.preventDefault(); // prevent natural form submission

	var cat_name = document.getElementById("cat_name").value;
	var formData = new FormData();
	formData.append('cat_name', cat_name);
	formData.append('ch', 'add_category');

	document.getElementById("report").innerHTML = '';
	var bfr_cont = document.getElementById("process_div").innerHTML;
	document.getElementById("process_div").innerHTML = '<img src="../images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			document.getElementById("process_div").innerHTML = bfr_cont;
			if (xmlHttp.responseText.substr(0, 7) == 'success') {
				var id = xmlHttp.responseText.substr(7);
				var row = document.createElement('tr');
				row.id = 'row_' + id;
				row.innerHTML = '<td>new</td><td style="font-size:20px;">' + cat_name + '</td><td class="edit_area"><button onClick="delete_category(' + id + ')">&times;</button></td>';
				document.getElementById('cat_parent').prepend(row);
				document.getElementById("cat_name").value = '';
			}
			else {
				document.getElementById("report").innerHTML = xmlHttp.responseText;

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}



function delete_category(cat_id) {
	var conf = confirm('Do you want to delete this Category. \n All sub categories and Menu under this categort will be deleted also. \n  Click Okay to continue or cancel');
	if (!conf) return;

	var formData = new FormData();
	formData.append('cat_id', cat_id);
	formData.append('ch', 'delete_category');

	var bfr_cont = document.querySelector('#row_' + cat_id + ' .edit_area').innerHTML;
	document.querySelector('#row_' + cat_id + ' .edit_area').innerHTML = '<img src="../images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			if (xmlHttp.responseText == 'success') {
				document.getElementById('row_' + cat_id).remove();
			}
			else {
				document.querySelector('#row_' + cat_id + ' .edit_area').innerHTML = bfr_cont;
				alert(xmlHttp.responseText);

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}


function delete_row(table, id) {
	var conf = confirm('Do you want to delete this Record');
	if (!conf) return;

	var formData = new FormData();
	formData.append('id', id);
	formData.append('table', table);
	formData.append('ch', 'delete_row');

	var bfr_cont = document.querySelector('#row_' + id + ' .edit_area').innerHTML;
	document.querySelector('#row_' + id + ' .edit_area').innerHTML = '<img src="../images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			if (xmlHttp.responseText == 'success') {
				document.getElementById('row_' + id).remove();
			}
			else {
				document.querySelector('#row_' + id + ' .edit_area').innerHTML = bfr_cont;
				alert(xmlHttp.responseText);

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}



function add_menu(event) {
	event.preventDefault(); // prevent natural form submission

	var category = document.getElementById("category").value;
	var name = document.getElementById("name").value;
	var price = document.getElementById("price").value;
	var desc_n = document.getElementById("desc_n").value;

	var formData = new FormData();
	formData.append('category', category);
	formData.append('name', name);
	formData.append('price', price);
	formData.append('desc_n', desc_n);
	formData.append('ch', 'add_menu');


	document.getElementById("report").innerHTML = '';
	var bfr_cont = document.getElementById("process_div").innerHTML;
	document.getElementById("process_div").innerHTML = '<img src="../images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			if (xmlHttp.responseText.substr(0, 7) == 'success') {
				window.location.href = 'menu.php';
			}
			else {
				document.getElementById("process_div").innerHTML = bfr_cont;
				document.getElementById("report").innerHTML = xmlHttp.responseText;

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	//xmlHttp.setRequestHeader);
	xmlHttp.send(formData);
}


function update_menu(event, mid) {
	event.preventDefault(); // prevent natural form submission

	var category = document.getElementById("category").value;
	var name = document.getElementById("name").value;
	var price = document.getElementById("price").value;
	var desc_n = document.getElementById("desc_n").value;


	var formData = new FormData();
	formData.append('category', category);
	formData.append('name', name);
	formData.append('price', price);
	formData.append('desc_n', desc_n);
	formData.append('mid', mid);
	formData.append('ch', 'update_menu');


	document.getElementById("report").innerHTML = '';
	var bfr_cont = document.getElementById("process_div").innerHTML;
	document.getElementById("process_div").innerHTML = '<img src="../images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			if (xmlHttp.responseText == 'success') {
				window.location.href = 'menu.php';
			}
			else {
				document.getElementById("process_div").innerHTML = bfr_cont;
				document.getElementById("report").innerHTML = xmlHttp.responseText;

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	//xmlHttp.setRequestHeader);
	xmlHttp.send(formData);
}


function delete_menu(mid) {

	var conf = confirm('Do you want to delete this menu Item. Click Okay to continue or cancel');
	if (!conf) return;

	var formData = new FormData();
	formData.append('mid', mid);
	formData.append('ch', 'delete_menu');

	var bfr_cont = document.getElementById("process_div").innerHTML;
	document.getElementById("process_div").innerHTML = '<img src="../images/spinner.gif" style="width:1.8rem">';

	var xmlHttp = new XMLHttpRequest();
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			if (xmlHttp.responseText == 'success') {
				document.getElementById('menu_' + mid).remove();
			}
			else {
				document.getElementById("process_div").innerHTML = bfr_cont;
				alert(xmlHttp.responseText);

			}
		}
	}
	xmlHttp.open("post", "connections/main.php");
	xmlHttp.send(formData);
}

