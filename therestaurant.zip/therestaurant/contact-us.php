<?php
session_start();

require 'config/config.php';


$pdo = new mypdo();
$menus = $pdo->get_menus();
$cats = $pdo->get_categories();


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/main.css">
    <title>Contact Us</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="./">Home</a>
        <a href="./#about_us">About US</a>
        <a href="menu.php">Menu</a>
        <a class="active" href="contact-us.php">Contact Us</a>
        <a href="reservation.php">Reservation</a>
        <?php echo get_login_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <h2 class="home-title"> <span>Contact</span> Us</h2>
            <div class="home-slag-2">Your request/feedback is of paramount important to us </div>
        </div>
    </header>
    <section class="">
        <div class="container" style="text-align:center">

            <div style="display:inline-block; width:100%; max-width:700px; text-align:left">
                <form id="contact_form" onSubmit="contact_us(event)">
                    <div class="form-group">
                        <label>FullName</label>
                        <input required id="fname">
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input required id="email" type="email">
                    </div>
                    <div class="form-group">
                        <label>Subject</label>
                        <input required id="subject">
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <textarea rows="5" required id="message" placeholder="Query/Complain"></textarea>
                    </div>
                    <div class="radio-group" style="background-color:#F3F4EA; padding:20px 5px">
                        <p><i>Please help us review our services. This will help us serve you better.</i></p>
                        <p>How will you rate your Satisfaction Level with us? </p>

                        <label><input type="radio" name="review" value=""><span></span>No Idea</label>
                        <label><input type="radio" name="review" value="Very Poor"><span></span>Very Poor</label>
                        <label><input type="radio" name="review" value="Poor"><span></span>Poor</label>
                        <label><input type="radio" name="review" value="Just Okay"><span></span>Just Okay</label>
                        <label><input type="radio" name="review" value="Good"><span></span>Good</label>
                        <label><input type="radio" name="review" value="Very Good"><span></span>Very Good</label>
                        <label><input type="radio" name="review" value="Excellent"><span></span>Excellent</label>

                    </div>
                    <div id="report"></div>
                    <div style="text-align:center; padding:20px;" id="process_div">
                        <button class="btn-primary"> Submit</button>
                    </div>

                </form>
            </div>


        </div>
    </section>


    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>


    <script src="js/main.js"></script>

</body>

</html>