<?php 
session_start();
require "../../config/config.php";
check_admin_login(1);

$GLOBALS['global_report'] = '';




if(isset($_POST['ch']) && $_POST['ch'] == 'add_category'){
	
	$cat_name = validate('Category Name', 1, 100, $_POST['cat_name']);
	
	if($GLOBALS['global_report'] !== '') //validation failed
		die($GLOBALS['global_report']);
	
	$pdo = new mypdo();
	$result = $pdo->add_category($cat_name);
	die($result);
	

}

if(isset($_POST['ch']) && $_POST['ch'] == 'delete_category'){
	
	$cat_id = $_POST['cat_id'];
	$pdo = new mypdo();
	$pdo->gen_qry_one("DELETE FROM categories WHERE id = ?", $cat_id);
	die('success');

}

if(isset($_POST['ch']) && $_POST['ch'] == 'delete_row'){
	
	$id = $_POST['id'];
	$table = $_POST['table'];
	
	$pdo = new mypdo();
	if($table == 'contacts')
		$pdo->gen_qry_one("DELETE FROM contacts WHERE id = ?", $id);
	elseif($table == 'reservation')
		$pdo->gen_qry_one("DELETE FROM reservation WHERE id = ?", $id);
	
	die('success');

}





if(isset($_POST['ch']) && $_POST['ch'] == 'add_menu'){
	
	$category = validate('Category', 1, 100, $_POST['category']);
	$name = validate('Display Status', 4, 100, $_POST['name']);
	$desc_n = validate('Description', 12, 1000, $_POST['desc_n']);
	$price = $_POST['price'];	
	
	if($GLOBALS['global_report'] !== '') //validation failed
		die($GLOBALS['global_report']);

	$pdo = new mypdo();
	$result = $pdo->add_menu($category, $name, $desc_n, $price);
	die($result);

}

elseif(isset($_POST['ch']) && $_POST['ch'] == 'update_menu'){
	
	$category = validate('Category', 1, 100, $_POST['category']);
	$name = validate('Display Status', 2, 100, $_POST['name']);
	$desc_n = validate('Description', 12, 1000, $_POST['desc_n']);
	$price = $_POST['price'];
	$mid = (int)$_POST['mid'];	
	
	if($GLOBALS['global_report'] !== '') //validation failed
		die($GLOBALS['global_report']);
	
	
	$pdo = new mypdo();
	$mime = '';
	
	$result = $pdo->update_menu($category, $name, $desc_n, $price, $mid);
	die($result);
	

}


elseif(isset($_POST['ch']) && $_POST['ch'] == 'delete_menu'){
	
	$mid = $_POST['mid'];	
	$pdo = new mypdo();
	die($pdo->delete_menu($mid));
	

}