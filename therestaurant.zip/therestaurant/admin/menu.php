<?php
session_start();
require '../config/config.php';
check_admin_login(0);

$pdo = new mypdo();

$menus = $pdo->get_menus();
$cats = $pdo->get_categories();



?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>ADMIN - MENU</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="../">Home</a>
        <a href="../#about_us">About US</a>
        <a href="../menu.php">Menu</a>
        <a href="../contact-us.php">Contact Us</a>
        <a href="../reservation.php">Reservation</a>
        <?php echo get_login_admin_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="../images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <div class="admin-area-header"><span>ADMIN AREA</span><a href="contact.php">CONTACT</a><a
                    href="reservation.php">RESERVATION</a><a href="menu.php" class="active">MENU</a><a
                    href="categories.php">CATEGORIES</a></div>
        </div>
    </header>
    <section class="menu_section">
        <div class="container">
            <div class="home-slag-3"><a id="tab_all" class="active" onClick="view_menu('all')"> All</a>
                <?php foreach( $cats as $cat) echo '<a id="tab_'.$cat['id'].'" onClick="view_menu(\''.$cat['id'].'\')">'.$cat['name'].'</a>';?>
            </div>

            <h3 style="text-align:center">Menu <a class="addmin_add_new_flt" href="add-menu.php">&plus; ADD A MEMU</a>
            </h3>


            <div class="row" style="margin-top:30px">
                <?php foreach($menus as $menu){  ?>
                <div class="menu-item-p cat_<?php echo $menu['cat_id']; ?>" id="menu_<?php echo $menu['id']; ?>">
                    <div class="menu-item">
                        <a href="../menu-item.php?m_id=<?php echo $menu['id']; ?>">
                            <div class="dstatus"><?php echo $menu['name']; ?> </div>
                            <div class="price"><?php echo format_currency($menu['price']); ?></div>
                            <div class="category"><?php echo $menu['cat_name']; ?></div>
                        </a>
                        <div class="edit_area" id="process_div"><button
                                onClick="delete_menu(<?php echo $menu['id']; ?>)"> &times; Delete</button><a
                                href="edit-menu.php?mid=<?php echo $menu['id']; ?>">Edit</a></div>
                    </div>
                </div>
                <?php } ?>

            </div>



        </div>
    </section>


    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>


    <script src="../js/main.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>