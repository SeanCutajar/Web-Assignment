<?php
session_start();
require '../config/config.php';
check_admin_login(0);


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>ADMIN - NEWS</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="../">Home</a>
        <a href="../#about_us">About US</a>
        <a href="../menu.php">Menu</a>
        <a href="../contact-us.php">Contact Us</a>
        <a href="../reservation.php">Reservation</a>
        <?php echo get_login_admin_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="../images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <div class="admin-area-header"><span>ADMIN AREA</span><a href="contact.php">CONTACT</a><a
                    href="reservation.php">RESERVATION</a><a href="menu.php">MENU</a><a
                    href="categories.php">CATEGORIES</a></div>
        </div>
    </header>
    <section>

        <p style="text-align:center; padding:100px; font-size:25px;">Welcome to Admin Area. </p>

    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>


    <script src="../js/main.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>