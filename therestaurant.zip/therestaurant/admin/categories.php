<?php
session_start();
require '../config/config.php';

check_admin_login(0);


$pdo = new mypdo();
$cats = $pdo->get_categories();


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>ADMIN - Menu Categories</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="../">Home</a>
        <a href="../#about_us">About US</a>
        <a href="../menu.php">Menu</a>
        <a href="../contact-us.php">Contact Us</a>
        <a href="../reservation.php">Reservation</a>
        <?php echo get_login_admin_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="../images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <div class="admin-area-header"><span>ADMIN AREA</span><a href="contact.php">CONTACT</a><a
                    href="reservation.php">RESERVATION</a><a href="menu.php">MENU</a><a href="categories.php"
                    class="active">CATEGORIES</a></div>
        </div>
    </header>
    <section class="news_section">
        <div class="container" style="text-align:center">
            <h3>Categories </h3>
            <div class="central_frame">

                <form autocomplete="off" onSubmit="add_category(event)" style="margin-bottom:20px;">
                    <div class="form-group" style="max-width:300px; display:inline-block">
                        <label>Category Name</label>
                        <input id="cat_name" required minlength="4" maxlength="100">
                    </div>
                    <div style="display:inline-block">
                        <div id="report" class="status_report"></div>
                        <div id="process_div">
                            <button class="submit_btn"> &plus; ADD</button>
                        </div>
                    </div>
                </form>


                <table>
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Name</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="cat_parent">
                        <?php
					$sn = 0;
					foreach($cats as $cat){ $sn++;  ?>
                        <tr id="row_<?php echo $cat['id']; ?>">
                            <td><?php echo $sn; ?></td>
                            <td style="font-size:20px;"><?php echo $cat['name']; ?></td>
                            <td class="edit_area"><button
                                    onClick="delete_category(<?php echo $cat['id']; ?>)">&times;</button></td>
                        </tr>

                        <?php } ?>
                    </tbody>

                </table>

            </div>

        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>

    <script src="../js/main.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>