<?php
session_start();
require '../config/config.php';

check_admin_login(0);


$pdo = new mypdo();

$cats = $pdo->get_categories();


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>ADMIN - ADD MENU</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="../">Home</a>
        <a href="../#about_us">About US</a>
        <a href="../menu.php">Menu</a>
        <a href="../contact-us.php">Contact Us</a>
        <a href="../reservation.php">Reservation</a>
        <?php echo get_login_admin_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="../images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <div class="admin-area-header"><span>ADMIN AREA</span><a href="contact.php">CONTACT</a><a
                    href="reservation.php">RESERVATION</a><a href="menu.php" class="active">MENU</a><a
                    href="categories.php">CATEGORIES</a></div>
        </div>
    </header>
    <section class="news_section">
        <div class="container" style="text-align:center">
            <div class="central_frame">
                <h3>ADD A MENU </h3>
                <form autocomplete="off" onSubmit="add_menu(event)">
                    <div class="form-group" style="max-width:300px;">
                        <label>Category</label>
                        <select id="category" required>
                            <option></option>
                            <?php
							foreach($cats as $cat){
								echo '<option value="'.$cat['id'].'">'.$cat['name'].'</option>';
								}
						?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Menu Name</label>
                        <input id="name" required minlength="2" maxlength="100">
                    </div>
                    <div class="form-group" style="max-width:150px;">
                        <label>Price</label>
                        <input id="price" required min="0.1" type="number" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea rows="10" id="desc_n" required minlength="12" maxlength="1000"></textarea>
                    </div>
                    <div id="report" class="status_report"></div>
                    <div id="process_div">
                        <button class="submit_btn"> Submit</button>
                    </div>
                </form>
            </div>

        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>

    <script src="../js/main.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>