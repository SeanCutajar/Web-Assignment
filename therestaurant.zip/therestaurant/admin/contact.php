<?php
session_start();
require '../config/config.php';

check_admin_login(0);


$pdo = new mypdo();
$contacts = $pdo->get_contacts();


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>ADMIN - Contacts</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="../">Home</a>
        <a href="../#about_us">About US</a>
        <a href="../menu.php">Menu</a>
        <a href="../contact-us.php">Contact Us</a>
        <a href="../reservation.php">Reservation</a>
        <?php echo get_login_admin_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="../images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <div class="admin-area-header"><span>ADMIN AREA</span><a href="contact.php" class="active">CONTACT</a><a
                    href="reservation.php">RESERVATION</a><a href="menu.php">MENU</a><a
                    href="categories.php">CATEGORIES</a></div>
        </div>
    </header>
    <section class="">
        <div class="container" style="text-align:left">
            <h3>Contacts</h3>
            <div style="overflow-x:auto">
                <table>
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Date</th>
                            <th>FullName</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Review</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="cat_parent">
                        <?php
                    $sn = 0;
                    foreach($contacts as $contact){ $sn++;  ?>
                        <tr id="row_<?php echo $contact['id']; ?>">
                            <td><?php echo $sn; ?></td>
                            <td><?php echo date("l j, @ h:i a", strtotime($contact['date_time'])); ?></td>
                            <td><?php echo $contact['fname']; ?></td>
                            <td><?php echo $contact['email']; ?></td>
                            <td><?php echo $contact['subject']; ?></td>
                            <td><?php echo $contact['message']; ?></td>
                            <td><?php echo $contact['review']; ?></td>
                            <td class="edit_area"><button
                                    onClick="delete_row('contacts', <?php echo $contact['id']; ?>)">&times;</button>
                            </td>
                        </tr>

                        <?php } ?>
                    </tbody>

                </table>
            </div>

        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>

    <script src="../js/main.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>