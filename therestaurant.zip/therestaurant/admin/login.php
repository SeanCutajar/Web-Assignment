<?php
session_start();

require '../config/config.php';

if(isset($_POST['username']) && isset($_POST['password'])){
	
	if($_POST['username'] == 'admin' && $_POST['password'] == '1234'){
		$_SESSION['admin'] = '1';
		$_SESSION['user'] = 'Admin';	
		header("Location: ./");
		exit();
	}
	else{
		header("Location: login.php?error=username and password not match");
		exit();
	}
}
			


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>ADMIN - Login</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="../">Home</a>
        <a href="../#about_us">About US</a>
        <a href="../menu.php">Menu</a>
        <a href="../contact-us.php">Contact Us</a>
        <a href="../reservation.php">Reservation</a>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="../images/menu_bar.png">
        </a>
    </nav>


    <section>

        <p style="text-align:center; padding:50px; font-size:25px;">Welcome to Admin Area. </p>
        <h2 style="text-align:center">Login</h2>

        <form style="text-align:center" method="post">
            <div style="display:inline-block; max-width:500px; width:100%; text-align:left">
                <p style="color:red; text-align:center"><?php echo @$_GET['error'] ?></p>

                <div class="form-group">
                    <label>Username</label>
                    <input name="username" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input name="password" required type="password">
                </div>
                <div style="margin-top:30px;">
                    <button class="btn-primary">Login</button>
                </div>
            </div>
        </form>


    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>


    <script src="../js/main.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>