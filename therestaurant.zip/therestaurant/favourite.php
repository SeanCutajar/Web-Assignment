<?php
session_start();
require './config/config.php';


$pdo = new mypdo();


?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/main.css">
    <title>My Favourite</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="./">Home</a>
        <a href="./#about_us">About US</a>
        <a href="./menu.php">Menu</a>
        <a href="./contact-us.php">Contact Us</a>
        <a href="./reservation.php">Reservation</a>
        <?php echo get_login_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="./images/menu_bar.png">
        </a>
    </nav>
    <section class="news_section">
        <div class="container" style="text-align:left">
            <h3>My Favourite Menus </h3>
            <p id="favourite_nop"
                style="padding:20px; text-align:center; background-color:#E8E8E8; margin:100px 10px; display:none">You
                don't have any menu in your favourite list</p>
            <div id="favourite_table" style="display:none; min-height:50vh">
                <table>
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Menu Name</th>
                            <th>Menu Category</th>
                            <th>Unit Price</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="favourite_menus">
                    </tbody>

                </table>
            </div>

        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>

    <script src="./js/main.js"></script>

</body>

</html>