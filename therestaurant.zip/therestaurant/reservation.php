<?php
session_start();

require 'config/config.php';

$pdo = new mypdo();



/*
	We will try get the dates 
	A user can book within the next three days
	There is no date for monday and tuesday
	We will use php date function;
*/


$select_options = "<option></option>";
$iday = 1;
$limit = 3;
while($limit != 0){
	$next_date = date("l", strtotime("+".$iday." day"));
	if($next_date == "Monday" || $next_date == "Tuesday"){
		
		//do nothing
	}
	else{
		$date = date("l, F jS", strtotime("+".$iday." day"));
		$date_val = date("Y-m-d", strtotime("+".$iday." day"));
		$select_options .= '<option value="'.$date_val.'">'.$date.'</option>';
		$limit--;
	}
	$iday++;	
	
}


/*
  The block below will generate time interval of 15minutes
  Booking time will be between  9am and 4: 45pm
*/

$select_options2 = "<option></option>";

$cur_time = strtotime(date("Y-m-d 9:00:00")); // 9am

$end_time = strtotime(date("Y-m-d 16:45:00")); // 4:45pm

while($end_time > $cur_time){
		
		$time = date("h:i a", $cur_time);
		$select_options2 .= '<option value="'.$time.'">'.$time.'</option>';
		
		$cur_time = $cur_time + (15 * 60); //increament by 15 mins
}




?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/main.css">
    <title>Table Reservation</title>
</head>

<body>

    <nav class="topnav" id="myTopnav">
        <a href="./">Home</a>
        <a href="./#about_us">About US</a>
        <a href="menu.php">Menu</a>
        <a href="contact-us.php">Contact Us</a>
        <a class="active" href="reservation.php">Reservation</a>
        <?php echo get_login_html(); ?>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="images/menu_bar.png">
        </a>
    </nav>

    <header>
        <div class="container">
            <h2 class="home-title"> <span>Table</span> Reservation</h2>
            <div class="home-slag-2">Save the Time! Ensure you and and your friends have space whenever you visit our
                restaurant </div>
        </div>
    </header>

    <section class="">


        <div class="container">
            <div> <b>Why Book for a table now?</b> </div>
            <ul>
                <li>You and your friends or family are always guarantee a table space when you visit at the appointed
                    time</li>
                <li>You and your friends or family will be able to sit close to each other</li>
                <li>Free drink for one (When you are more than 4)</li>
                <li>Qualify for our weekly give away </li>
            </ul>
            <div style="display:inline-block; width:100%; max-width:950px; text-align:left">
                <form id="contact_form" onSubmit="book_reservation(event)">
                    <div class="form-group" style="max-width:400px">
                        <label>FullName</label>
                        <input required id="fname">
                    </div>

                    <div class="form-group" style="max-width:400px">
                        <label>Email Address</label>
                        <input required id="email" type="email">
                    </div>

                    <div class="form-group" style="max-width:400px">
                        <label>Phone</label>
                        <input required id="phone" type="tel">
                    </div>


                    <p>Select any of the table below. You can book for multiple Table</p>
                    <table class="table_reserve">
                        <tr>
                            <th>Table Type</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>No. of Table</th>
                        </tr>
                        <tr id="row_0">
                            <td>
                                <img src="images/table_1.jpeg"><br>
                                <span class="name">Classic Wooden table with 4 chairs</span>
                            </td>
                            <td class="form-group">
                                <select class="date"><?php echo $select_options; ?></select>
                            </td>
                            <td class="form-group">
                                <select class="time"><?php echo $select_options2; ?></select>
                            </td>
                            <td class="form-group">
                                <select class="amount">
                                    <option></option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                            </td>
                        </tr>
                        <tr id="row_1">
                            <td>
                                <img src="images/table_2.jpeg"><br>
                                <span class="name">Double 10 rows of Chair</span>
                            </td>
                            <td class="form-group">
                                <select class="date"><?php echo $select_options; ?></select>
                            </td>
                            <td class="form-group">
                                <select class="time"><?php echo $select_options2; ?></select>
                            </td>
                            <td class="form-group">
                                <select class="amount">
                                    <option></option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                            </td>
                        </tr>
                        <tr id="row_2">
                            <td>
                                <img src="images/table_3.jpeg"><br>
                                <span class="name">Pair of Chairs with a round table</span>
                            </td>
                            <td class="form-group">
                                <select class="date"><?php echo $select_options; ?></select>
                            </td>
                            <td class="form-group">
                                <select class="time"><?php echo $select_options2; ?></select>
                            </td>
                            <td class="form-group">
                                <select class="amount">
                                    <option></option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                            </td>
                        </tr>
                    </table>



                    <div id="report"></div>
                    <div style="text-align:center; padding:20px;" id="process_div">
                        <button class="btn-primary"> Submit</button>
                    </div>

                </form>
            </div>


        </div>
    </section>


    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <p>&copy 2021 - The Taste Experience</p>
            </div>
        </div>
    </footer>


    <script src="js/main.js"></script>

</body>

</html>